APP_SDK_NAME="NielsenAGFAppSDK"
DISTRIBUTOR="AGF"
BUNDLE_NAME="NielsenAppApi"
APP_SDK_VERSION='6.1.0.1'

CACHE_LIFETIME=604800

BUNDLE_PATH="$APP_SDK_NAME/$BUNDLE_NAME.framework"
README_FILE="../$APP_SDK_NAME-ReadMe.md"
PODFILE_PATH="../Podfile"
BASE_URL="https://raw.githubusercontent.com/nielsendigitalsdk/nielsenappsdk-ios/master"
README_URL="$BASE_URL/$APP_SDK_NAME-ReadMe.md"
LAST_UPDATE_TIMESTAMP_FILE="../$APP_SDK_NAME-LastUpdate.timestamp"

NIELSEN_APP_SDK_DEFINITION_PATTERN="s/^[[:space:]]*(pod[[:space:]]+'$APP_SDK_NAME'[[:space:]]*(,[[:space:]]*(:)?.*[[:space:]]*$|[[:space:]]*$))/\1/p"
NIELSEN_APP_SDK_VERSION_DEFINITION_PATTERN="s/.*,[[:space:]]*'([[:space:]]*(>|<|=|<=|>=|~>)?[[:space:]]*[[:digit:]]+(\.[[:digit:]]+)*)'.*/\1/p"
NIELSEN_APP_SDK_SIGN_PATTERN="s/^(>|<|=|<=|>=|~>).*/\1/p"
NIELSEN_APP_SDK_VERSION_NUMBER_PATTERN="s/([[:digit:]]+(\.[[:digit:]]+)*)/\1/p"

COMPARE_RESULT_EQ=0
COMPARE_RESULT_ASC=1
COMPARE_RESULT_DESC=2

SUCCESS=1
FAILURE=0

README_UPDATE_STATUS_CACHED=2
README_UPDATE_STATUS_UPDATED=1
README_UPDATE_STATUS_FAILED=0

TARGET_WATCHOS=3
TARGET_MACOS=2
TARGET_TVOS=1
TARGET_IPHONEOS=0

UPDATE_TO_MAJOR="UPDATE_TO_MAJOR"
UPDATE_TO_GLOBAL="UPDATE_TO_GLOBAL"
UPDATE_TO_SPECIFIC="UPDATE_TO_SPECIFIC"

VERSION_ND=""
VERSION_EQ="="
VERSION_GT=">"
VERSION_GE=">="
VERSION_LT="<"
VERSION_LE="<="

#################
VERSION_TW="~>" # APPLIES ONLY FOR MAJOR VERSIONS
#################
#"~> 5.1.1.29" -> [5.1.1.29; 6.0.0.0)
#"~> 6.0.0.3"  -> [6.0.0.3; 7.0.0.0)
#"~> 6.0"  -> 	  [6.0.0.0; 7.0.0.0)


###################################
###SCRIPT SPECIFIC FILE MANAGING###
###################################

shouldGetGlobalReadMeFromTheServer() {
	if isFileExist $LAST_UPDATE_TIMESTAMP_FILE && isFileExist $README_FILE;
	then
		local creationTime=$(lastUpdateTimestampFromFile $LAST_UPDATE_TIMESTAMP_FILE)
		local currentTime=$(date +%s)
		local lifetime=$((currentTime - creationTime))
		[ $lifetime -ge $CACHE_LIFETIME ];
	else
		true;
	fi
}

writeTimestampToFile() {
	writeContentToFile "$(date +%s)" $2
}

lastUpdateTimestampFromFile() {
	local content="$(fileContent $1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
	local currentTime=$(date +%s)

	if [ ! -z "$content" -a "$content" != " " ];
	then
		if [[ "$content" =~ ^[0-9]{10}$ ]];
		then
			echo $content
		else
			echo $((currentTime - CACHE_LIFETIME - 1));
		fi
	else
		echo $((currentTime - CACHE_LIFETIME - 1));
	fi
}

###################
###FILE MANAGING###
###################

isFileExist() {
	[ -s "$1" ]
}

isFolderExist() {
	[ -d "$1" ]
}

removeFile() {
	if [ -f $1 ];
	then
		rm $1
	fi
}

removeFolder() {
	rm -rf "$1"
}

removeFoldersContent() {
	rm -rf "$1"/*
}

grantPermissionsForFile() {
	if isFileExist $1;
	then
		chmod a+x "$1"
	fi
}

fileContent() {
	if isFileExist $1;
	then
		grantPermissionsForFile $1
		local content=$(<$1)
		echo "$content"
	else
		echo ""
	fi
}

writeContentToFile() {
	grantPermissionsForFile "$2";
	echo "$1" > "$2"
}


#######################
###VERSION COMPARING###
#######################

showDifference() {
	local difference=""
	local newestVersionFound=false

	while IFS='' read -r line || [[ -n "$line" ]]; do
		local version="$(echo "$line" | sed -n -E "s/^[[:space:]]*([[:digit:]]+(\.[[:digit:]]+)*)[[:space:]]*$/\1/p")"
		if [ ! -z "$version" -a "$version" != " " ];
		then
			compareVersions "$APP_SDK_VERSION" "$version" comparisonResult
			if [ $comparisonResult == $COMPARE_RESULT_ASC ];
			then
				difference="$difference\n\n$line"
				newestVersionFound=true;
			else
				break;
			fi
		else
			difference="$difference\n$line"
		fi
	done < "$README_FILE"

	if $newestVersionFound;
	then
		echo -e "$difference"
	fi
}

##compares two versions and writes to the result variable
##v1 = 1.0.0.0
##v2 = 1.0.0.1
##v3 = 1.0.0.0
##v4 = 0.1.0.1

##compareVersions v1 v2 result
##result = COMPARE_RESULT_ASC

##compareVersions v1 v3 result
##result = COMPARE_RESULT_EQ

##compareVersions v1 v4 result
##result = COMPARE_RESULT_DESC

compareVersions() {
	local __resultVar=$3
	if [[ $1 == $2 ]]
	then
		eval $__resultVar=$COMPARE_RESULT_EQ
	return
	fi
	local IFS=.
	local i ver1=($1) ver2=($2)
	# fill empty fields in ver1 with zeros
	for ((i=${#ver1[@]}; i<${#ver2[@]}; i++))
	do
		ver1[i]=0
	done
	for ((i=0; i<${#ver1[@]}; i++))
	do
		if [[ -z ${ver2[i]} ]]
		then
			# fill empty fields in ver2 with zeros
			ver2[i]=0
		fi
		if ((10#${ver1[i]} > 10#${ver2[i]}))
		then
			eval $__resultVar=$COMPARE_RESULT_DESC
			return
		fi
		if ((10#${ver1[i]} < 10#${ver2[i]}))
		then
			eval $__resultVar=$COMPARE_RESULT_ASC
			return
		fi
	done
	eval $__resultVar=$COMPARE_RESULT_EQ
	return
}


updateGlobalReadMe() {
	if shouldGetGlobalReadMeFromTheServer;
	then
		local readMeContent=$(curl -sS --fail $README_URL --netrc)
		if [  ! -z "$readMeContent" -a "$readMeContent" != " " ]
		then
			writeContentToFile "$readMeContent" $README_FILE
			writeTimestampToFile "$(date +%s)" $LAST_UPDATE_TIMESTAMP_FILE
			return $README_UPDATE_STATUS_UPDATED
		else
			return $README_UPDATE_STATUS_FAILED
		fi
	fi
	return $README_UPDATE_STATUS_CACHED
}

#Versions are mentioned in the ReadMe file in descending order
getAppSDKVersionNumbers() {
	local readMe="$(fileContent $README_FILE)"
	local versions="$(echo "$readMe" | sed -n -E "s/^[[:space:]]*([[:digit:]]+(\.[[:digit:]]+)*)[[:space:]]*$/\1/p")"
	echo "$versions"
}

getLatestVersionNumber() {
	IFS=$'\n' read -rd '' -a versionsArray <<<"$(getAppSDKVersionNumbers)"
	unset IFS
	echo "$versionsArray"
}

getPodfilePodDefintion() {
	local podfileContent="$(fileContent $PODFILE_PATH)"
	local podDefinition="$(echo "$podfileContent" | sed -n -E "$NIELSEN_APP_SDK_DEFINITION_PATTERN")"
	echo "$podDefinition"
}

getPodfileVersionDefinitionFromPodDefinition() {
	local podVersionDefinition="$(echo "$1" | sed -n -E "$NIELSEN_APP_SDK_VERSION_DEFINITION_PATTERN")"
	echo "$podVersionDefinition"
}

getPodfileVersionSignFromDefinition() {
	echo "$(echo "$1" | sed -n -E "$NIELSEN_APP_SDK_SIGN_PATTERN")"
}

getPodfileVersionNumberFromDefinition() {
	[[ "$1" =~ [0-9]+(\.[0-9]+)* ]] && echo "${BASH_REMATCH[0]}"
}

getMajorVersion() {
	IFS=$'.' read -rd '' -a versionElements <<<"$1"
	unset IFS

	echo "$versionElements"
}

#Gets target OS from the list:
#watchsimulator watchos
#macosx
#appletvsimulator appletvos
#iphoneos iphonesimulator

#TARGET_WATCHOS=3
#TARGET_MACOS=2
#TARGET_TVOS=1
#TARGET_IPHONEOS=0

getTargetOS() {
	local platformName="${PLATFORM_NAME}"
	if [[ "$platformName" = *"iphoneos"* ]] || [[ "$platformName" = *"iphonesimulator"* ]];
	then
		return $TARGET_IPHONEOS;
	fi
	if [[ "$platformName" = *"appletvos"* ]] || [[ "$platformName" = *"appletvsimulator"* ]];
	then
		return $TARGET_TVOS;
	fi
	if [[ "$platformName" = *"macosx"* ]];
	then
		return $TARGET_MACOS;
	fi
	if [[ "$platformName" = *"watchos"* ]] || [[ "$platformName" = *"watchsimulator"* ]];
	then
		return $TARGET_WATCHOS;
	fi

	return $TARGET_IPHONEOS
}

getOSFolder() {
	getTargetOS
	local targetOS=$?
	case "$targetOS" in
		"$TARGET_IPHONEOS")
			echo "iOS"
		;;
		"$TARGET_TVOS")
			echo "tvOS"
		;;
		"$TARGET_MACOS")
			echo "macOS"
		;;
		"$TARGET_WATCHOS")
			echo "watchOS"
		;;
		*)
			echo "iOS"
		;;
	esac
}

buildPathToTheRelease() {
	local version="$1"
	local pathToFile="$BASE_URL/$(getOSFolder)/$DISTRIBUTOR/$APP_SDK_NAME-$version.zip"
	echo "$pathToFile"
}

fetchSDKForVersion() {
	local version="$1"
	local pathToFile="$(buildPathToTheRelease "$version")"
	local tempFilename="$APP_SDK_NAME-$version.zip"

	removeFile $tempFilename
	removeFile $LAST_UPDATE_TIMESTAMP_FILE
	if ! curl -sS --fail -o "$tempFilename" "$pathToFile" --netrc;
	then
		return $FAILURE;
	fi

	if ! isFileExist $tempFilename;
	then
		return $FAILURE;
	fi

	removeFoldersContent "$APP_SDK_NAME"

	unzip -qq "$tempFilename" -d "$APP_SDK_NAME"

	removeFile $tempFilename

	if [ "$(ls -A $APP_SDK_NAME)" ];
	then
		writeTimestampToFile "$(date +%s)" $LAST_UPDATE_TIMESTAMP_FILE
		return $SUCCESS;
	else
		return $FAILURE;
	fi
}

isVersionExist() {
	local version="$1"
	IFS=$'\n' read -rd '' -a releaseVersions <<<"$2"
	unset IFS

	for releaseVersion in ${releaseVersions[@]}
	do
		if [[ "$version" == "$releaseVersion" ]];
		then
			true
			return
		fi
	done
	false
}

#Updates SDK with up to major version from the provided version
#Returns new version number string or empty if it was not updated
#$1 - Target At Least Version
#$2 - Pointer to the argument where release version will be written to
#$3 - Updating strategy: MAJOR, GLOBAL or SPECIFIC
#$4 - Current App SDK Version
#$5 - Should forcely update

updateSDKFromTheVersion() {
	local targetVersion="$1"
	local versionUpdateLogic="$3"
	local appSDKVersion="$4"
	local forceUpdate=$5

	if [ ! -z "$targetVersion" -a "$targetVersion" != " " ] && [ ! -z "$versionUpdateLogic" -a "$versionUpdateLogic" != " " ] && [ ! -z "$appSDKVersion" -a "$appSDKVersion" != " " ]
	then
		echo "";
	else
		echo "One of the required parameters is not provided."
		eval "$2=''"
		return $FAILURE;
	fi

	local appSDKVersionNumbers="$(getAppSDKVersionNumbers)"
	IFS=$'\n' read -rd '' -a releaseVersions <<<"$appSDKVersionNumbers"
	unset IFS

	if [ ! -z "$releaseVersions" -a "$releaseVersions" != " " ]
	then
		echo ""
	else
		echo "Unable to retrieve release versions."
		eval "$2=''"
		return $FAILURE;
	fi

	local releaseVersionToUpdateTo=""

	if [ "$versionUpdateLogic" == "$UPDATE_TO_MAJOR" ]
	then
		local majorTargetVersion="$(getMajorVersion "$targetVersion")"
		#Get the first version, the major version of which is equal to
		#the major version of the 'targetVersion' and greater than or equal to 'targetVersion'
		for releaseVersion in ${releaseVersions[@]}
		do
			local majorReleaseVersion="$(getMajorVersion "$releaseVersion")"
			compareVersions "$targetVersion" "$releaseVersion" comparisonResult
			if [[ "$majorTargetVersion" == "$majorReleaseVersion"  && ( $comparisonResult == $COMPARE_RESULT_EQ || $comparisonResult == $COMPARE_RESULT_ASC ) ]]; 
			then
				releaseVersionToUpdateTo="$releaseVersion";
				break;
			fi
		done
	elif [ "$versionUpdateLogic" == "$UPDATE_TO_GLOBAL" ]
	then
		releaseVersionToUpdateTo="${releaseVersions[0]}"
	elif [ "$versionUpdateLogic" == "$UPDATE_TO_SPECIFIC" ]
	then
		releaseVersionToUpdateTo="$targetVersion"
		if ! isVersionExist "$releaseVersionToUpdateTo" "$appSDKVersionNumbers";
		then
			echo "warning: No release versions for '$targetVersion' update is found. Consider to update your CocoaPods repository."
			eval "$2=''"
			return $FAILURE;
		fi
	fi


	if [ "$releaseVersionToUpdateTo" == "" ]
	then
		echo "warning: No release versions for '~> $targetVersion' update is found. Consider to update your CocoaPods repository."
		eval "$2=''"
		return $FAILURE;
	fi

	if [[ "$appSDKVersion" == "$releaseVersionToUpdateTo" ]] && ( ! $forceUpdate )
	then
		eval "$2='$releaseVersionToUpdateTo'"
		return $SUCCESS;
	fi

	echo "Updating $APP_SDK_NAME to the version: $releaseVersionToUpdateTo.";
	fetchSDKForVersion "$releaseVersionToUpdateTo"
	local fetchResult=$?

	if [ $fetchResult == $SUCCESS ];
	then
		echo ""
		echo "$APP_SDK_NAME '$releaseVersionToUpdateTo' has been downloaded."
		eval "$2='$releaseVersionToUpdateTo'"
		return $SUCCESS;
	else
		echo ""
		echo "Unable to download the $APP_SDK_NAME"
		eval "$2=''"
		return $FAILURE;
	fi
}


##########
###MAIN###
##########

##compares current version with global remote version

compareLatesReleaseAndCurrentVersions() {
	local remoteVersion="$1"
	local currentVersion="$2"

	compareVersions "$currentVersion" "$remoteVersion" comparisonResult

	if [ $comparisonResult -ne $COMPARE_RESULT_EQ ];
	then
		if [ $comparisonResult == $COMPARE_RESULT_ASC ];
		then
			echo "warning: Your version of the $APP_SDK_NAME ($APP_SDK_VERSION) is old! The new version is available ($remoteVersion)."
			showDifference
		else
			echo "warning: Your version of the $APP_SDK_NAME ($APP_SDK_VERSION) is not published for the market. It is not guaranted that the SDK will work properly."
		fi
	fi
}

checkAppSDKVersion() {
	updateGlobalReadMe
	local readmeUpdateStatus=$?
	if [ $readmeUpdateStatus == $README_UPDATE_STATUS_FAILED ];
	then
		echo "Unable to retrieve ReadMe file from the Server."
		echo "warning: Your version of the SDK ($APP_SDK_VERSION) is not guaranted to be fresh."
		return $FAILURE;
	fi

	local podDefinition="$(getPodfilePodDefintion)"
	if [ -z "$podDefinition" ]
	then
		echo "warning: There is no definition for the $APP_SDK_NAME in Podfile. Removing the $APP_SDK_NAME content and interrupting."
		removeFolder "$BUNDLE_PATH"
		return $FAILURE;
	fi

	local podVersionDefinition="$(getPodfileVersionDefinitionFromPodDefinition "$podDefinition")"
	local podSign="$(getPodfileVersionSignFromDefinition "$podVersionDefinition")"
	local podVersion="$(getPodfileVersionNumberFromDefinition "$podVersionDefinition")"

	if [[ "$podSign" != "$VERSION_TW" ]] && [[ "$podSign" != "$VERSION_ND" ]]
	then
		echo "warning: '$podSign' sign in Podfile is not supported!"
		return $FAILURE
	fi

	local targetVersion="$APP_SDK_VERSION"

	#Detect if the podfile has been changed
	if [ ! -z "$podVersion" -a "$podVersion" != " " ]
	then
		compareVersions "$podVersion" "$APP_SDK_VERSION" comparisonResult
		if [[ $comparisonResult != $COMPARE_RESULT_EQ ]]
		then
			#Mark SDK to be force updated if its version doesn't match with version in podfile
			# 6.0.0.4 <-> 5.1.1.29
			# 5.1.1.29 <-> 6.0.0.4
			# 5.1.1.29 <-> 7.0.0
			targetVersion="$podVersion"
		fi
	fi

	local forceUpdate=false;
	if ! isFolderExist $BUNDLE_PATH;
	then
		forceUpdate=true;
	fi

	if [ "$podSign" == "$VERSION_TW" ]
	then
		updateSDKFromTheVersion "$targetVersion" versionUpdatedTo "$UPDATE_TO_MAJOR" "$APP_SDK_VERSION" $forceUpdate
	elif [ "$podVersion" == "" ]
	then
		updateSDKFromTheVersion "$targetVersion" versionUpdatedTo "$UPDATE_TO_GLOBAL" "$APP_SDK_VERSION" $forceUpdate
	elif [ "$podSign" == "$VERSION_ND" ] && [ ! -z "$podVersion" -a "$podVersion" != " " ]
	then
		updateSDKFromTheVersion "$targetVersion" versionUpdatedTo "$UPDATE_TO_SPECIFIC" "$APP_SDK_VERSION" $forceUpdate
	fi

	if [ ! -z "$versionUpdatedTo" -a "$versionUpdatedTo" != " " ]
	then
		APP_SDK_VERSION="$versionUpdatedTo"
	fi

	local latestReleaseVersion="$(getLatestVersionNumber)"
	if [ ! -z "$latestReleaseVersion" -a "$latestReleaseVersion" != " " ]
	then
		compareLatesReleaseAndCurrentVersions "$latestReleaseVersion" "$APP_SDK_VERSION"
	else
		echo "warning: Cannot fetch the latest release version. It is not guaranted that the SDK work properly."
	fi
}

#################
###ENTRY POINT###
#################

checkAppSDKVersion



